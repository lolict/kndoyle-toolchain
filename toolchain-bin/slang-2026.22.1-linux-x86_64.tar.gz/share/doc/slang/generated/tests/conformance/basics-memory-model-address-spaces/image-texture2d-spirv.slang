//META: generated=true
//META: model=claude-sonnet-4-6
//META: generated_at=2026-06-02T09:58:38+00:00
//META: source_commit=57fb63455095efe1465661001ad147b24b968932
//META: doc_ref=docs/language-reference/basics-memory-model-address-spaces.md#address-spaces
//META: doc_section_digest=3851dfb34bba532778d07931eed37a5ffb7720f62c8acf95efe83c116ec49a46
//META: purpose=`Texture2D<T>` belongs to the Image address space; SPIRV emits the variable with `UniformConstant` storage class.
//META: intent=functional
//META: pipeline_stage=emit
//META: warning=Auto-generated. May drift from source. Do not edit by hand.

// Verifies that `Texture2D<T>` belongs to the Image address space. The shader samples the
// texture and writes the result to an output buffer so DCE cannot remove the resource;
// CHECK asserts the SPIRV assembly declares `%myTexture` as `OpVariable ... UniformConstant`,
// confirming the Image address space maps to the UniformConstant storage class.

//TEST:SIMPLE(filecheck=CHECK):-target spirv-asm -entry computeMain -stage compute
//TEST:SIMPLE(filecheck=METAL):-target metal -entry computeMain -stage compute
//TEST:SIMPLE(filecheck=WGSL):-target wgsl -entry computeMain -stage compute
//TEST:SIMPLE(filecheck=GLSL):-target glsl -entry computeMain -stage compute
//TEST:SIMPLE(filecheck=HLSL):-target hlsl -entry computeMain -stage compute

Texture2D<float4>  myTexture;
SamplerState       mySampler;

[numthreads(1, 1, 1)]
void computeMain(uint3 tid : SV_DispatchThreadID, RWStructuredBuffer<float4> output)
{
    output[0] = myTexture.SampleLevel(mySampler, float2(0.5, 0.5), 0.0);
}

// CHECK: %myTexture = OpVariable {{.*}} UniformConstant
// Metal emits Texture2D as a texture2d<float, access::sample> parameter.
// METAL: texture2d<float, access::sample> myTexture_
// WGSL emits Texture2D as a texture_2d<f32> variable.
// WGSL: var myTexture_{{.*}} : texture_2d<
// GLSL emits the Image-address-space texture as a `uniform texture2D` (separate-texture form).
// GLSL: uniform texture2D myTexture_
// HLSL emits it as a Texture2D bound to a `t` register (SRV).
// HLSL: Texture2D<float4{{.*}}> myTexture_{{.*}} : register(t
