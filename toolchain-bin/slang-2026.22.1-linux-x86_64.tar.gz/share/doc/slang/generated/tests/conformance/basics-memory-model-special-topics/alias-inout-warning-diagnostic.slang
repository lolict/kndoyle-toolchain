//META: generated=true
//META: model=claude-sonnet-5-5
//META: generated_at=2026-11-02T10:45:10+00:00
//META: source_commit=6815ed82d5e8c95b0e1258ca2eba0ca9c7825d86
//META: doc_ref=docs/language-reference/basics-memory-model-special-topics.md#function-parameters-with-inout-inout-modifiers
//META: doc_section_digest=50b3040fe642ee135f57002e37f20cd9b949f33677eec525295c406b3b231822
//META: purpose=Passing the same variable to two `inout` parameters of one function call elicits diagnostic W30051 (potentially aliased argument to out/inout/ref parameter).
//META: intent=negative
//META: pipeline_stage=check
//META: warning=Auto-generated. May drift from source. Do not edit by hand.

// Verifies that passing the same variable to two `inout` parameters of one call
// triggers diagnostic W30051. The call site passes `a` as both the first and third
// argument to a function with three `inout` parameters; CHECK asserts the
// caret-anchored W30051 alias warning fires on that argument position.

//DIAGNOSTIC_TEST:SIMPLE(diag=CHECK):-target hlsl -entry computeMain -stage compute

RWStructuredBuffer<int> output;

void addConsumeTwoValues(
    inout int i1, inout int i2, inout int o)
{
    o += i1;
    i1 = -1;
    o += i2;
    i2 = -1;
}

[numthreads(1,1,1)]
void computeMain(uint3 dispatchThreadID: SV_DispatchThreadID)
{
    int a = dispatchThreadID.x;
    int b = dispatchThreadID.y;
    // undefined behavior: a is passed twice to inout parameters
    addConsumeTwoValues(a, b, a);
//CHECK:                ^ potentially aliased argument to a parameter that may be written
//CHECK:                ^ argument for 'inout' parameter 'i1' may alias argument for 'inout' parameter 'o'; passing the same value to both may produce undefined behavior
    output[0] = a;
}
