//META: generated=true
//META: model=claude-sonnet-5-5
//META: generated_at=2026-06-02T07:58:38+00:00
//META: source_commit=ae4e57957a0adad3061b069b0e0eec8217779338
//META: doc_ref=docs/language-reference/declarations.md#subscripts
//META: doc_section_digest=96fe50283b71fe44fe9a09f0fc0cff5190f23935a1a109bbcdaf1cb870ea319d
//META: purpose=The result type clause of a `__subscript` declaration cannot be elided; a `__subscript` without `->` is a compile error (E30901).
//META: intent=negative
//META: pipeline_stage=check
//META: warning=Auto-generated. May drift from source. Do not edit by hand.

// Verifies that omitting the `->` result type from a `__subscript` is a compile error.
// A subscript without an explicit return type must trigger E30901; CHECK-DAG asserts
// both the error severity and the diagnostic code.

//DIAGNOSTIC_TEST:SIMPLE(filecheck=CHECK, exit-code=2):

struct Bad
{
    __subscript(int i)
    {
        get { return 0; }
    }
}

void main() {}

// CHECK-DAG: error
// CHECK-DAG: E30901
