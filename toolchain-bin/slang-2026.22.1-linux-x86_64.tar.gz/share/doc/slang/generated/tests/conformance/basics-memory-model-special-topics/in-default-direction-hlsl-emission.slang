//META: generated=true
//META: model=claude-sonnet-4-6
//META: generated_at=2026-06-02T10:01:20+00:00
//META: source_commit=57fb63455095efe1465661001ad147b24b968932
//META: doc_ref=docs/language-reference/basics-memory-model-special-topics.md#function-parameters-with-inout-inout-modifiers
//META: doc_section_digest=50b3040fe642ee135f57002e37f20cd9b949f33677eec525295c406b3b231822
//META: purpose=`in` is the default parameter direction: a parameter declared without a direction modifier emits identically to one declared with explicit `in`, both without `inout`/`out` on the HLSL signature.
//META: intent=functional
//META: pipeline_stage=emit
//META: warning=Auto-generated. May drift from source. Do not edit by hand.

// Verifies that a parameter with no direction modifier is treated identically to one
// marked `in`. Both `readImplicit(int val)` and `readExplicit(in int val)` are compiled;
// CHECK asserts both emit plain value parameters (no `inout` or `out` in the signature),
// and CHECK-NOT confirms neither modifier appears in the HLSL output.

//TEST:SIMPLE(filecheck=CHECK):-target hlsl -entry computeMain -stage compute
//TEST:SIMPLE(filecheck=GLSL):-target glsl -entry computeMain -stage compute
//TEST:SIMPLE(filecheck=MTL):-target metal -entry computeMain -stage compute
//TEST:SIMPLE(filecheck=WGSL):-target wgsl -entry computeMain -stage compute
//TEST:SIMPLE(filecheck=SPIRV):-target spirv-asm -entry computeMain -stage compute

RWStructuredBuffer<int> output;

[noinline]
void readImplicit(int val)
{
    output[2] = val;
}

[noinline]
void readExplicit(in int val)
{
    output[3] = val;
}

[numthreads(1,1,1)]
void computeMain(uint3 tid : SV_DispatchThreadID)
{
    int x = output[0];
    readImplicit(x);
    readExplicit(x);
}

// CHECK: void readImplicit_{{[0-9]+}}(int val_{{[0-9]+}})
// CHECK-NOT: inout
// CHECK-NOT: out int
// CHECK: void readExplicit_{{[0-9]+}}(int val_{{[0-9]+}})

// GLSL: void readImplicit_{{[0-9]+}}(int val_{{[0-9]+}})
// GLSL: void readExplicit_{{[0-9]+}}(int val_{{[0-9]+}})
// GLSL-NOT: inout
// GLSL-NOT: out int

// MTL: void readImplicit_{{[0-9]+}}(int val_{{[0-9]+}}
// MTL: void readExplicit_{{[0-9]+}}(int val_{{[0-9]+}}
// MTL-NOT: int thread* val

// WGSL: fn readImplicit_{{[0-9]+}}( val_{{[0-9]+}} : i32)
// WGSL: fn readExplicit_{{[0-9]+}}( val_{{[0-9]+}} : i32)
// WGSL-NOT: ptr<function

// SPIRV-NOT: OpTypePointer Function
// SPIRV: %readImplicit = OpFunction %void DontInline
// SPIRV: %val = OpFunctionParameter %int
// SPIRV: %readExplicit = OpFunction %void DontInline
// SPIRV: %val_{{[0-9]+}} = OpFunctionParameter %int
